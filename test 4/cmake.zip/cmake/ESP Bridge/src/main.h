#pragma once

#include <Arduino.h>
#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>
#define MAC_ADDRESS_LENGTH 6
#define MAC_ADDRESS_TOTAL 12

extern uint8_t mac_addresses[MAC_ADDRESS_TOTAL][MAC_ADDRESS_LENGTH];
extern const char *mac_names[MAC_ADDRESS_TOTAL];
extern bool isReceivingJson; 

extern esp_err_t mulai_esp_now(int index_mac_address);
extern int cari_mac_index(const uint8_t *mac);
extern String mac_index_to_names(int mac_index);

extern void callback_data_esp_now(const uint8_t *mac, const uint8_t *data, int len);
extern void callback_pengiriman_esp_now(const uint8_t *mac_addr, esp_now_send_status_t status);

extern void baca_serial(void (*callback)(const uint8_t *data, int len));
extern void callback_data_serial(const uint8_t *data, int len);

extern void process_perintah(const uint8_t *data, int len, int index_mac_address_asal);

extern void relay_data_via_espnow(uint8_t *target_mac, const uint8_t *data, int len);
