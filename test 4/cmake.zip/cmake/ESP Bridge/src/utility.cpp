#include "main.h"

uint8_t mac_addresses[MAC_ADDRESS_TOTAL][MAC_ADDRESS_LENGTH] = {
    {0x24, 0x0A, 0xC4, 0x0A, 0x21, 0x11},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x21, 0x10},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x20, 0x11},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x10, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x10, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x11, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x11, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x12, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x12, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x13, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x13, 0x11},
};

const char *mac_names[MAC_ADDRESS_TOTAL] = {
    "BISMA", 
    "JSON", 
    "FARUG",
    "Fauzan Firdaus", 
    "Africha Sekar Wangi", 
    "Rafaina Erin Sadia", 
    "Antonius Michael Yordanis Hartono",
    "Dinda Sofi Azzahro", 
    "Muhammad Fahmi Ilmi", 
    "Dhanishara Zaschya Putri Syamsudin", 
    "Irsa Fairuza", 
    "Revalinda Bunga Nayla Laksono",
};
esp_now_peer_info_t peer_info;
const size_t ESPNOW_CHUNK_SIZE = 240; 

esp_err_t mulai_esp_now(int index_mac_address) {
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();

    esp_err_t result = esp_now_init();
    if (result != ESP_OK) return result;

    result = esp_now_register_recv_cb(callback_data_esp_now);
    if (result != ESP_OK) return result;

    result = esp_now_register_send_cb(callback_pengiriman_esp_now);

    uint8_t mac[MAC_ADDRESS_LENGTH];
    memcpy(mac, mac_addresses[index_mac_address], MAC_ADDRESS_LENGTH);
    result = esp_wifi_set_mac(WIFI_IF_STA, mac);
    if (result != ESP_OK) return result;

    memset(&peer_info, 0, sizeof(esp_now_peer_info_t));
    peer_info.channel = 0;
    peer_info.encrypt = false;

    for (int i = 0; i < MAC_ADDRESS_TOTAL; i++) {
        memcpy(peer_info.peer_addr, mac_addresses[i], MAC_ADDRESS_LENGTH);
        result = esp_now_add_peer(&peer_info);
        if (result != ESP_OK) return result;
    }

    return ESP_OK;
}

int cari_mac_index(const uint8_t *mac) {
    for (int i = 0; i < MAC_ADDRESS_TOTAL; i++) {
        if (memcmp(mac, mac_addresses[i], MAC_ADDRESS_LENGTH) == 0)
            return i;
    }
    return -1;
}

String mac_index_to_names(int mac_index) {
    if ((mac_index < 0 || mac_index >= MAC_ADDRESS_TOTAL) || (mac_index == -1)) {
        return "Unknown";
    }
    return mac_names[mac_index];
}

void callback_data_esp_now(const uint8_t *mac, const uint8_t *data, int len) {
    int index_mac_asal = cari_mac_index(mac);
    Serial.printf("[BRIDGE] Data diterima dari %s. (Len: %d). Abaikan di mode Relay.\n", mac_index_to_names(index_mac_asal).c_str(), len);
}

void callback_pengiriman_esp_now(const uint8_t *mac_addr, esp_now_send_status_t status) {
    const char* mac_name = mac_index_to_names(cari_mac_index(mac_addr)).c_str();
    if (status == ESP_NOW_SEND_SUCCESS) {
    } else {
        Serial.printf("Pengiriman ke %s GAGAL.\n", mac_name);
    }
}