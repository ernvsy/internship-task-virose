#include "main.h"

extern uint8_t mac_addresses[MAC_ADDRESS_TOTAL][MAC_ADDRESS_LENGTH];
extern const char *mac_names[MAC_ADDRESS_TOTAL]; 
bool isReceivingJson = false;


void setup() {
    const int SERIAL_BAUD = 115200;
    Serial.begin(SERIAL_BAUD);
    Serial.setTimeout(50); 
    
    Serial.println("Initializing ESP Bridge");
    if (mulai_esp_now(0) != ESP_OK) { 
        Serial.println(" ERROR ESP-NOW.");
    } else {
        Serial.printf("ESP-NOW OK. Bridge MAC: %s\n", mac_names[0]);
    }
    Serial.flush(); 
    Serial.println( "Buffer serial dibersihkan. Siap menerima data PC.");
}

void loop() {
    baca_serial(callback_data_serial);
}

void baca_serial(void (*callback)(const uint8_t *data, int len)) {
    int available_bytes = Serial.available();
    
    if (available_bytes > 0) {
        const int MAX_BUFFER_SIZE = 512; 
        uint8_t buffer[MAX_BUFFER_SIZE];
        int bytes_to_read = (available_bytes > MAX_BUFFER_SIZE) ? MAX_BUFFER_SIZE : available_bytes;
        int bytes_read = Serial.readBytes((char*)buffer, bytes_to_read);

        if (bytes_read > 0) {
            callback(buffer, bytes_read);
        }
    }
}
void relay_data_via_espnow(uint8_t *target_mac, const uint8_t *data, int len) {
    const size_t ESPNOW_MAX_PAYLOAD = 250; 
    
    for (int i = 0; i < len; i += ESPNOW_MAX_PAYLOAD) {
        int chunk_size = (len - i) > ESPNOW_MAX_PAYLOAD ? ESPNOW_MAX_PAYLOAD : (len - i);
        esp_now_send(target_mac, data + i, chunk_size);
    }
}

void callback_data_serial(const uint8_t *data, int len) {
    uint8_t *target_mac = mac_addresses[5]; 
    String received_str((const char*)data, len);

    if (received_str.startsWith("START_JSON:")) {
        isReceivingJson = true;
        
        esp_now_send(target_mac, data, len);
        
        Serial.printf("Protocol START_JSON dikirimkan kepada %s.\n", mac_names[1]);
        return; 
    }
    
    if (received_str.startsWith("END_JSON")) {
        isReceivingJson = false;
        esp_now_send(target_mac, data, len);

        Serial.printf("Protocol END_JSON dikirimkan kepada %s.\n", mac_names[1]);
        return;
    }

    if (isReceivingJson) {
        Serial.printf("Menerima Serial Chunk (%d bytes). Diteruskan via ESP-NOW...\n", len);
        relay_data_via_espnow(target_mac, data, len);
    }
}
void process_perintah(const uint8_t *data, int len, int index_mac_address_asal) {
    if (index_mac_address_asal != -1) {

        String received_data = String((char*)data).substring(0, len);
        String mac_name = mac_index_to_names(index_mac_address_asal);
        Serial.printf("DITERIMA Perintah dari %s (Len: %d): %s\n", mac_name.c_str(), len, received_data.c_str());
    }
}