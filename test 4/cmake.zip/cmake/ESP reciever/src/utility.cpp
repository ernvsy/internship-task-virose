#include "main.h"

esp_now_peer_info_t peer_info;

uint8_t mac_addresses[MAC_ADDRESS_TOTAL][MAC_ADDRESS_LENGTH] = {
    {0x24, 0x0A, 0xC4, 0x0A, 0x21, 0x11},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x21, 0x10},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x20, 0x11},  
    {0x24, 0x0A, 0xC4, 0x0A, 0x10, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x10, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x11, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x11, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x12, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x12, 0x11}, 
    {0x24, 0x0A, 0xC4, 0x0A, 0x13, 0x10},
    {0x24, 0x0A, 0xC4, 0x0A, 0x13, 0x11},

};

const char *mac_names[MAC_ADDRESS_TOTAL] = {
   "BISMA", 
    "JSON", 
    "FARUG",
    "Fauzan Firdaus", 
    "Africha Sekar Wangi", 
    "Rafaina Erin Sadia", 
    "Antonius Michael Yordanis Hartono",
    "Dinda Sofi Azzahro", 
    "Muhammad Fahmi Ilmi", 
    "Dhanishara Zaschya Putri Syamsudin", 
    "Irsa Fairuza", 
    "Revalinda Bunga Nayla Laksono",
};

esp_err_t mulai_esp_now(int index_mac_address) {
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();

    esp_err_t result = esp_now_init();
    if (result != ESP_OK) return result;

    esp_now_register_send_cb(callback_pengiriman_esp_now);

    esp_wifi_set_mac(WIFI_IF_STA, mac_addresses[index_mac_address]);

    memset(&peer_info, 0, sizeof(peer_info));
    peer_info.channel = 0;
    peer_info.encrypt = false;

    for (int i = 0; i < MAC_ADDRESS_TOTAL; i++) {
        memcpy(peer_info.peer_addr, mac_addresses[i], MAC_ADDRESS_LENGTH);
        esp_now_add_peer(&peer_info);
    }
    return ESP_OK;
}
int cari_mac_index(const uint8_t *mac) {
    for (int i = 0; i < MAC_ADDRESS_TOTAL; i++) {
        if (memcmp(mac, mac_addresses[i], MAC_ADDRESS_LENGTH) == 0) return i;
    }
    return -1;
}

String mac_index_to_names(int mac_index) {
    if (mac_index < 0 || mac_index >= MAC_ADDRESS_TOTAL) return "Unknown";
    return mac_names[mac_index];
}


