#pragma once
#include <Arduino.h>
#include <EEPROM.h>
#include <WiFi.h>
#include <esp_err.h>
#include <esp_now.h>
#include <esp_wifi.h>

#define MAC_ADDRESS_INDEX 0
#define EEPROM_SIZE 128
#define MAC_ADDRESS_TOTAL 12
#define MAC_ADDRESS_LENGTH 6
#define BUFFER_SIZE 250  

extern uint8_t mac_addresses[MAC_ADDRESS_TOTAL][MAC_ADDRESS_LENGTH];
extern const char *mac_names[MAC_ADDRESS_TOTAL];
extern esp_now_peer_info_t peer_info;

esp_err_t mulai_esp_now(int index_mac_address);
int cari_mac_index(const uint8_t *mac);
String mac_index_to_names(int mac_index);

void forward_serial_to_espnow(int receiver_index);
void callback_pengiriman_esp_now(const uint8_t *mac_addr, esp_now_send_status_t status);
