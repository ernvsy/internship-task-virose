#include "receiver.h"
#include "main.h"

const int mac_index_ku = 5;

void setup() {
  init_receiver();
}

void loop() {
  CheckFileExistance();
  if (isReceiving);
  delay(200);
}
