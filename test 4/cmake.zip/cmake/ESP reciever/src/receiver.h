#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <SPIFFS.h>
#include <ArduinoJson.h>

#define FILE_PATH "/received2BUATTEST.json"
#define BUFFER_SIZE 250

extern bool isReceiving;
extern String currentJsonBuffer;
extern size_t totalExpectedSize;

void init_receiver();
void onDataRecv(const uint8_t* mac, const uint8_t* data, int len);
void process_json_file();
void CheckFileExistance();