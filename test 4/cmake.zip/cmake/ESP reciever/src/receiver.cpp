#include "receiver.h"
bool isReceiving = false;
String currentJsonBuffer = "";
size_t totalExpectedSize = 0;

const size_t JSON_DOC_SIZE = 1024; //1 kb
const size_t JSON_BUFFER_MAX = 250; 

void process_json_string() {
  Serial.println("\n Data JSON Lengkap Diterima.");
  Serial.printf("Ukuran Buffer: %d bytes\n", currentJsonBuffer.length());
  
  if (currentJsonBuffer.length() == 0) {
    Serial.println("[RECEIVER] ERROR: Buffer JSON kosong.");
    return;
  }
  StaticJsonDocument<JSON_DOC_SIZE> doc;
  
  DeserializationError err = deserializeJson(doc, currentJsonBuffer);

  currentJsonBuffer = "";
  totalExpectedSize = 0;

  if (err) {
    Serial.printf("Gagal parsing file: %s\n", err.f_str());
    return;
  } 
  const char* nama = doc["Nama"] | "T/A";
  const char* jurusan = doc["jurusan"] | "T/A";
  int umur = doc["umur"] | 0;
  const char* deskripsi = doc["deskripsi"] | "T/A";

  Serial.println("\n--- HASIL PARSING JSON ---");
  Serial.printf("NAMA: %s\n", nama);
  Serial.printf("JURUSAN: %s\n", jurusan);
  Serial.printf("UMUR: %d\n", umur);
  Serial.printf("DESKRIPSI DIRI: %s\n", deskripsi);
  Serial.println("--------------------------");
}
void onDataRecv(const uint8_t *mac, const uint8_t *incomingData, int len) {
  String received_str((const char*)incomingData, len);
  
  if (received_str.startsWith("START_JSON:")) {
    isReceiving = true;
    currentJsonBuffer = ""; 
    
    int sizeIndex = received_str.lastIndexOf(':');
    if (sizeIndex != -1) {
        totalExpectedSize = received_str.substring(sizeIndex + 1).toInt();
    } else {
        totalExpectedSize = 0;
    }

    Serial.printf("Mulai menerima file. Size: %d bytes.\n", totalExpectedSize);
    return;
  }

  if (received_str.startsWith("END_JSON")) {
    isReceiving = false;
    Serial.println("Protokol END_JSON diterima.");
    if (totalExpectedSize > 0 && currentJsonBuffer.length() == totalExpectedSize) {
        process_json_string();
    } else {
        Serial.printf("Ukuran tidak cocok! Expected: %d, Received: %d\n", totalExpectedSize, currentJsonBuffer.length());
        process_json_string(); 
    }
    return;
  }

  if (isReceiving) {
    if ((currentJsonBuffer.length() + len) <= totalExpectedSize) {
      currentJsonBuffer += received_str;
      float progress = (float)currentJsonBuffer.length() / totalExpectedSize * 100.0;
      Serial.printf("Progress: %.2f%% (%d/%d)\r", progress, currentJsonBuffer.length(), totalExpectedSize);

    } else {
      isReceiving = false;
      Serial.println("\n[RECEIVER] ERROR: Data melebihi batas yang diumumkan! Hentikan penerimaan.");
      currentJsonBuffer = "";
    }
  }
}

void init_receiver() {
  Serial.begin(115200);
  Serial.println("ESP Receiver");
  WiFi.mode(WIFI_STA);
  Serial.printf("MAC Address Receiver: %s\n", WiFi.macAddress().c_str());
  if (esp_now_init() != ESP_OK) {
    Serial.println("Gagal inisialisasi ESP-NOW");
    return;
  }
  
  esp_now_register_recv_cb(onDataRecv);
  Serial.println("ESP-NOW siap menerima data.");
}

void CheckFileExistance() {
  if (!SPIFFS.begin(true)) {
    Serial.println("SPIFFS Mount Failed");
    return;
  }

  if (SPIFFS.exists(FILE_PATH)) {
    Serial.println("FILE EXIST!");
  } else {
    Serial.println("NO FILE");
  }
}
