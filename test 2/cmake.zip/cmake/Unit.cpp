#include "Unit.h"
#include <iostream>

using namespace std;
using namespace rapidjson;

Unit::Unit(int id) : id(id) {}

void Unit::cobabaca(const Document& doc) {
    if (doc.HasMember("name")) name = doc["name"].GetString();
    if (doc.HasMember("total_frame")) totalFrame = doc["total_frame"].GetInt();

    if (doc.HasMember("time") && doc["time"].IsArray()) {
        for (auto& t : doc["time"].GetArray())
            time.push_back(t.GetInt());
    }

    if (doc.HasMember("motion_frame") && doc["motion_frame"].IsArray()) {
        for (auto& frameArray : doc["motion_frame"].GetArray()) {
            vector<int> frame;
            for (auto& val : frameArray.GetArray())
                frame.push_back(val.GetInt());
            motionFrame.push_back(frame);
        }
    }
}

void Unit::display() const {
    cout << " Motion Unit " << id  << endl;
    cout << "Nama: " << name << endl;
    cout << "Total Frame: " << totalFrame << endl;
    for (const auto& frame : motionFrame) {
        cout << "[";
        for (size_t i = 0; i < frame.size(); ++i) {
            cout << frame[i];
            if (i < frame.size() - 1) cout << ", ";
        }
        cout << "]\n";
    }
}

