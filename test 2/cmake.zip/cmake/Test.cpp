#include <iostream>
#include "JsonParser.h"
#include "movie.h"
#include "Unit.h"

using namespace std;

int main() {
    int M;
    cout << "Masukkan ID Movie (M): ";
    cin >> M;

    string basePath = "../../XL/";
    string moviePath = basePath + "motion_movie/" + to_string(M) + ".json";

    auto movieDoc = JsonParser::parseFile(moviePath);
    Movie movie(M);
    movie.cobabaca(movieDoc);
    movie.display();

    for (int unitId : movie.ambilunitid()) {
        string unitPath = basePath + "motion_unit/" + to_string(unitId) + ".json";
        auto unitDoc = JsonParser::parseFile(unitPath);
        Unit unit(unitId);
        unit.cobabaca(unitDoc);
        unit.display();
    }

    return 0;
}
