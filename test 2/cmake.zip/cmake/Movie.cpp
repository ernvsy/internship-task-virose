#include "movie.h"
#include <iostream>

using namespace std;
using namespace rapidjson;

Movie::Movie(int id) : id(id) {}

void Movie::cobabaca(const Document& doc) {
    if (doc.HasMember("name")) name = doc["name"].GetString();

    if (doc.HasMember("motion_unit") && doc["motion_unit"].IsArray()) {
        for (auto& u : doc["motion_unit"].GetArray()) {
            if (u.HasMember("id"))
                unitId.push_back(u["id"].GetInt());
        }
    }
}

vector<int> Movie::ambilunitid() const {
    return unitId;
}

void Movie::display() const {
    cout << "Motion Movie " << id << endl;
    cout << "Nama: " << name << endl;
    cout << "Unit yang dirujuk: ";
    for (auto id : unitId) cout << id << " ";
    cout << endl;
}
