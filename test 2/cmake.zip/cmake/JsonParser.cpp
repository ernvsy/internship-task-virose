#include "JsonParser.h"
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;
using namespace rapidjson;

Document JsonParser::parseFile(const string& filePath) {
    ifstream ifs(filePath);
    if (!ifs.is_open()) {
        cout << "Gagal membuka file: " << filePath << endl;
        exit(1);
    }

    stringstream buffer;
    buffer << ifs.rdbuf();
    string jsonData = buffer.str();

    Document doc;
    doc.Parse(jsonData.c_str());

    if (doc.HasParseError()) {
        cout << "Error parsing JSON: " << filePath << endl;
        exit(1);
    }

    return doc;
}
