#ifndef MOVIE_H
#define MOVIE_H

#include <string>
#include <vector>
#include <rapidjson/document.h>

class Movie {
private:
    int id;
    std::string name;
    std::vector<int> unitId;

public:
    Movie(int id);
    void cobabaca(const rapidjson::Document& doc);
    std::vector<int> ambilunitid() const;
    void display() const;
};

#endif
