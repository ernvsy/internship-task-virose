#ifndef UNIT_H
#define UNIT_H

#include <string>
#include <vector>
#include <iostream>            
#include <rapidjson/document.h>

class Unit {
private:
    int fileId;                
    int id;                    
    std::string name;
    int totalFrame;
    std::vector<int> time;
    std::vector<std::vector<int>> motionFrame;

public:
    Unit(int fileId);        
    void cobabaca(const rapidjson::Document& doc);
    void display() const;
};

#endif
