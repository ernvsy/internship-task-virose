#ifndef JSONPARSER_H
#define JSONPARSER_H

#include <string>
#include <rapidjson/document.h>

class JsonParser {
public:
    static rapidjson::Document parseFile(const std::string& filePath);
};

#endif
